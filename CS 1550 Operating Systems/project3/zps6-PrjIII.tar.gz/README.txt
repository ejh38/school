/*********************
 * Zach Sadler - zps6
 * CS 1550 - Project 3 
 * 12/10/13
 *********************/

 Compilation instructions:
 gcc VirtMemSim.c -o VirtMemSim

 Usage:
 ./VirtMemSim BACKING_STORE.bin addresses.txt

 Additional Comments:
 None, program produces identical output to 'correct.txt'.

 Have a nice holiday break!