Zach Sadler
zps6 @ pitt . edu
Assignment 3
11/24/13

I came very close to finishing the reader_priority, but did not finish. Please look through my source files to see how close I came and grade appropriately.

I did not implement the writer_priority program but I have the tools in place to do so.

I understand this is not a finalized project, but I'd appreciate consideration of my syscalls, as well as the reader_priority.c source file.