/**************************************
FILE: CS1566 Readme.txt
AUTHOR: Jane Doe
EMAIL: jud45@pitt.edu
PLATFORM: linux
HOMEWORK: 2
**************************************/


/* Under 'platform' above, let us know on what departmental
machine your homework will build and run, by choosing one 
of the below, as applicable: 
linux  macosx windowsvs windowscyg*/


Basic functionalities that my program is providing:




Known bugs (if any):



Extra credit (describe what you did, if anything):



Comments:  
