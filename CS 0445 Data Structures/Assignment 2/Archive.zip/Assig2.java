/* Zach Sadler
 * Assignment 2
 * Reads in a txt file from the command line,
 * performs operations accordingly, using a StackInterface
 * variable to manipulate an ArrayStack.
 * There's always money in the banana stand.
 */
 
import java.io.*;
import java.util.*;

public class Assig2
{
	public static void main(String [] args)
	{
	//---For reading in txt files---//
		String input;				// for nextLine
		int temp1, temp2, temp3;	// arguments for nextInt
		double temp4;				// needed for cost
		Scanner txtScan;			// to read from the txtFile
	//------------End---------------//
				
		int clock = 0;					// global clock
		
		// stack and crate variables
		StackInterface<Crate> stack = new ArrayStack<Crate>();
		StackInterface<Crate> tempStack = new ArrayStack<Crate>();
		Crate tempCrate1, tempCrate2, counterCrate = null; 
		
		// used for receiving
		boolean keepLooking = false;
		
		
		// Stuff for financial report
 		int recentCrates = 0, recentMoves = 0;
 		double recentBananaCost = 0, recentLaborCost = 0, recentTotal = 0;
 		int totalCrates = 0, totalMoves = 0; 
 		double totalLaborCost = 0, totalBananaCost = 0, totalTotal = 0;
 		
//--------Start of reading in the file--------//
		try{
			String file = args[0];
		txtScan = new Scanner(new File(file));
		
		while (txtScan.hasNextLine())
		{
			input = txtScan.nextLine();
			if (input.equals("receive"))
			{	
			// take in the number of crates, say you're receiving, then receive
				temp1 = txtScan.nextInt();
				
				// reset these variables
				recentCrates = temp1;
				recentBananaCost = 0;
				recentMoves = 0;
				recentLaborCost = 0;
				recentTotal = 0;
				
				System.out.println("\nReceiving " + temp1 + " crates of bananas");
				
				// iterate through for each crate received
				for (int i = 0; i < temp1; i++)
				{
					temp2 = txtScan.nextInt();			// exp
					temp3 = txtScan.nextInt();			// count
					temp4 = txtScan.nextDouble();		// cost
					tempCrate1 = new Crate(temp2, temp3, temp4);
					
					// add banana cost for each one
					recentBananaCost += temp4;
					
					keepLooking = true;
				while (keepLooking)
				{
					if (stack.isEmpty())
					{
						// if stack is empty, push the crate
						stack.push(tempCrate1);
						recentMoves++;
						keepLooking = false;
					}
					else
					{
						// stack is not empty
						tempCrate2 = stack.peek();
						if (tempCrate1.compareTo(tempCrate2) < 1)
						{
							// if the crate less than/equal to top stack
							if (tempStack.isEmpty())
							{
								// if tempStack is empty, then push onto tempStack
								tempStack.push(tempCrate1);
								recentMoves++;
								keepLooking = false;
							}
							else
							{
								// if tempStack isn't empty
								tempCrate2 = tempStack.peek();
								if (tempCrate1.compareTo(tempCrate2) > -1)
								{
									// if greater than/equal to top tempStack, then push onto tempStack
									tempStack.push(tempCrate1);
									recentMoves++;
									keepLooking = false;
								}
								else
								{
									// if less than top tempStack, pop off of tempStack, push onto stack
									stack.push(tempStack.pop());
									recentMoves++;
								}
							}
						}
						else
						// greater than the top of the Stack
						{
							// push from stack to tempStack
							tempStack.push(stack.pop());
							recentMoves++;
						}
					}
				}
				if (i == (temp1 - 1))
				{
					// if on the last item
					while (!tempStack.isEmpty())
					{
						// push everything back from temp -> stack
						stack.push(tempStack.pop());
						recentMoves++;
					}
				}

				}
				
				// add everything needed for report
				recentLaborCost += recentMoves;
				recentTotal		+= recentLaborCost + recentBananaCost;	
				totalCrates 	+= recentCrates;
				totalMoves 		+= recentMoves;
				totalBananaCost += recentBananaCost;
				recentLaborCost  = recentMoves;
				totalLaborCost  += recentLaborCost;
				totalTotal 		+= recentTotal;
				
				
			}	
			
			if (input.equals("report"))
			{		
				// display it all
				System.out.println("\nLickety Splits Financial Statement:");
				System.out.println("\tMost Recent Shipment:");
				System.out.println("\t\tCrates: " + recentCrates);
				System.out.println("\t\tBanana cost: " + recentBananaCost);
				System.out.println("\t\tLabor (moves): " + recentMoves);
				System.out.println("\t\tLabor cost: " + recentLaborCost);
				System.out.println("\t\t---------------------");
				System.out.println("\t\tTotal: " + recentTotal);
				System.out.println("\n\tOverall Expenses:");
				System.out.println("\t\tCrates: " + totalCrates);
				System.out.println("\t\tBanana cost: " + totalBananaCost);
				System.out.println("\t\tLabor (moves): " + totalMoves);
				System.out.println("\t\tLabor cost: " + totalLaborCost);
				System.out.println("\t\t---------------------");
				System.out.println("\t\tTotal: " + totalTotal + "\n");				
						
			}
			
			if (input.equals("display"))
			{
				if (counterCrate != null)	
					System.out.println("\nCurrent crate: " + counterCrate.toString());
				// pop the crates off the stack, putting them in turn onto the tempStack
				// and displaying their information each time
				if (stack.isEmpty())
					System.out.println("No more crates in the stack!");
				else
				{
					System.out.println("Stack crates (top to bottom):");
					while (!stack.isEmpty())
					{
						tempCrate1 = stack.pop();
						tempStack.push(tempCrate1);
						System.out.println(tempCrate1.toString());
					}
					// then put them back on
					while (!tempStack.isEmpty())
					{
						tempCrate1 = tempStack.pop();
						stack.push(tempCrate1);
					}
				}
			}			
			if (input.equals("use"))
			{		
				temp1 = txtScan.nextInt();
				System.out.println("\n" + temp1 + " bananas needed for order");
				while (temp1 > 0)
				{
					// while there are still bananas needed
					if (counterCrate == null || counterCrate.getCurr() == 0)
					{
						// this either gets a new counterCrate or says no more bananas
						if (stack.isEmpty())
						{
							System.out.println("Store is out of bananas! The Horror!!");
							temp1 = 0;
						}
						else
						{
							counterCrate = stack.pop();
							System.out.println("Getting crate: " + counterCrate.toString()
														+ " from the stack");
						}
					}
					else
					{
						temp2 = counterCrate.getCurr();
						temp3 = temp1 - temp2;
						if (temp3 <= 0)
						{
							// counterCrate has enough bananas
							counterCrate.useBananas(temp1);
							System.out.println(temp1 + " bananas used from current crate");
							temp1 = 0;
						}
						else
						{
							// not enough bananas
							temp1 -= temp2;
							counterCrate.useBananas(temp2);
							System.out.println(temp2 + " bananas used from current crate");
						}	
					}
				}						
					
				
			}
			
			if (input.equals("skip"))
			{	
				// increment global clock
				clock++;
				System.out.println("\nThe current day is now Day " + clock);
				while (!stack.isEmpty())
				{
					tempCrate1 = stack.pop();
					if (!tempCrate1.isExpired(clock))
					{
						// if the current crate isn't expired, throw it to the tempstack
						tempStack.push(tempCrate1);
					}
					else
					{
						// if it is, explain the crate is expired
						System.out.println("Top crate: " + tempCrate1.toString() + " is expired!");
						// and don't move it to the tempstack
					}
				}
				while (!tempStack.isEmpty())
				{
					stack.push(tempStack.pop());
				}
			}
			
		} // while hasNextLine
	
		} catch (IOException e)
		{		
			System.out.println("Oh no!");
			System.out.println(e.getStackTrace());		}
		
	
//--------------End file read----------//	
	}
	
}