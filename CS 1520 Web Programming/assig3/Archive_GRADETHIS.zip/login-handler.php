<?php
 session_start(); 
 ?>
<!DOCTYPE html>
<html>
	<head>
		<title>LINGO Player Logged In!</title>
		<link rel="stylesheet" type="text/css" href="such-style.css">
	</head>
<body>
<center>
	<h4>
	<a href = "lingo.html">Play LINGO!</a><br />
	<a href = "login.php">Log out :(</a><br />
	</h4>

</center>
</body>
</html>