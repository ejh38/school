<?php
	/* could potentially use this to redirect to the appropriate pages based
	 * on session variables
	 * (like to login, whatever)
	 */
	?>