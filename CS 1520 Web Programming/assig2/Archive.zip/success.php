<?php
 session_start(); 
?>

<!DOCTYPE html>
<html>
	<head>
		<title>(Actually) Make a Schedule!</title>
		<link rel="stylesheet" type="text/css" href="such-style.css">
	</head>
<body>
<center>

<h1>Great job man!<h1><br \>
<h3>You made your schedule and emails were sent out to all your friends!</h3>
<br \>
<br \>
Now feel free to <a href = "login-handler.php">go back to the last page</a> and finalize your schedule or logout.

</center>
</body>
</html>
